import { View, Image,Text, StyleSheet } from 'react-native'
import React from 'react'


const Tatal = ({imageSource}) => {
  return (
    <View style={{flex:1,}}>
      <View style={styles.maincontenar}>
        <Image source={imageSource}/>
      </View>
    </View>
  )
}

export default Tatal;
const styles =StyleSheet.create({
    maincontenar:{
        height:150,
        width:182,
        borderRadius:19,
        backgroundColor:'white',
        borderWidth:1,
        margin:10,
        justifyContent:'center',
        alignItems:'center',
    },
  
})