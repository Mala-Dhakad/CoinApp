import { View, Text, StyleSheet, Image } from 'react-native'
import React from 'react'

const Reward = ({ title, imageSource, titleone,backgroundcolor, }) => {
    return (
        <View style={{ flex: 1 }}>
            <View style={styles.container}>
               <View style={styles.flexStyle}>
                <Image/>
                <View style={styles.textstyle}>
                    <Text>{title}</Text>
                    <Text>{titleone}</Text>
                </View>
               </View>
            </View>
        </View>
    )
}

export default Reward;
const styles = StyleSheet.create({
    container: {
        width: 170,
        height: 60,
        borderWidth: 1,
        margin: 10,
        borderRadius: 10,
    },
    flexStyle:{
flexDirection:'row',
    },
    textstyle:{
        flexDirection:'column',
    }
})