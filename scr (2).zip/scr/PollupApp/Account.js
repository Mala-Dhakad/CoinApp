import { View, Text, ScrollView, StyleSheet, Image } from 'react-native'
import React from 'react'
import AccountCom from '../PollupAppCom/AccountCom'



const Account = () => {
      return (
            <View style={{ flex: 1 }}>
                  <ScrollView>
                        <View style={styles.contenar} >
                              <Image source={require("../assets/group.png")} style={styles.image} />
                              <Text style={styles.Account}>Account History</Text>
                        </View>
                        <AccountCom title={"Transaction ID # 456789"}
                              titleone={"Dec 2, 2023103:20 PM"}
                              withdrawal={"Withdrawal"}
                              amount={"Amount ₹10.00"}
                              pending={"completed"} />

                        <AccountCom title={"Transaction ID # 456789"}
                              titleone={"Dec 2, 2023103:20 PM"}
                              withdrawal={"Withdrawal"}
                              amount={"Amount ₹10.00"}
                              pending={"completed"}/>

                        <AccountCom title={"Transaction ID # 456789"}
                              titleone={"Dec 2, 2023103:20 PM"}
                              withdrawal={"Withdrawal"}
                              amount={"Amount ₹10.00"}
                              pending={"completed"} />

                        <AccountCom title={"Transaction ID # 456789"}
                              titleone={"Dec 2, 2023103:20 PM"}
                              withdrawal={"Withdrawal"}
                              amount={"Amount ₹10.00"}
                              pending={"completed"} />

                        <AccountCom title={"Transaction ID # 456789"}
                              titleone={"Dec 2, 2023103:20 PM"}
                              withdrawal={"Withdrawal"}
                              amount={"Amount ₹10.00"}
                              pending={"completed"} />

                  </ScrollView>
            </View>
      )
}

export default Account
const styles = StyleSheet.create({
      contenar: {
            flexDirection: 'row',
            backgroundColor: 'pink',
            width: '100%',
            height: 150,
            borderRadius: 20,
      },
      image: {

      },
      Account: {
            textAlign: 'center',
            alignSelf: 'center',
            color: 'black',
            fontSize: 18,
            fontWeight: "800",
      },
      color:{
            colo:'black'
      }
})