import { View, Text, Image, StyleSheet, ImageBackground } from 'react-native'
import React from 'react'
import ButtonGoogle from '../PollupAppCom/ButtonGoogle'

const LoginScreenPollUp = ({ navigation }) => {
  return (
    <View style={{ flex: 1, }}>
      <ImageBackground source={require("../assets/half.png")} style={styles.half}>

<Image source={require("../assets/PollupLogo.png")} style={styles.second}/> 
</ImageBackground>

      <Text style={styles.login}>Login</Text>
      <ButtonGoogle
        imageSource={require("../assets/google.png")}
        title={"Login"}
        onPress={()=>navigation.navigate("AuthScreen") }
         />
       
    </View >
  )
}

export default LoginScreenPollUp;
const styles = StyleSheet.create({
  half: {
    flex: 1,
    position: 'absolute',
    height: '80%',
    width: '100%',
   borderRadius:30,
  },
  login: {
    color: 'black',
    fontSize: 18,
    fontWeight: "800",
    marginHorizontal: 20,
    marginTop: 30,
  },
  second:{
    justifyContent: 'center', 
   alignSelf:'center',
  },
})















{/* <Image source={require("../assets/PollupLogo.png")}/> */ }
// half:{
// flex:1,
// position:'absolute',
// height:'100%',
// width:'100%',
// },