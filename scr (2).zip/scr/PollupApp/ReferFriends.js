import { View, Text,ScrollView } from 'react-native'
import React from 'react'
import ReferFrienCom from '../PollupAppCom/ReferFrienCom'
import ColorCom from '../PollupAppCom/ColorCom'


const ReferFriends = () => {
  return (
    <View style={{flex:1}}>
<ScrollView>
    <ColorCom/>
      <ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Update account"}/>

<ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Account History"}/>

<ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Reward History"}/>


 <ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Notification"}/>

<ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Payment Method"}/>

<ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Security"}/>

<ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Term and conditions"}/>

<ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Help"}/>

<ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"Delete Account"}/>

<ReferFrienCom imageSource={require("../assets/profileone.png")}
      title={"LogOut"}/> 
      </ScrollView>
    </View>
  )
}

export default ReferFriends