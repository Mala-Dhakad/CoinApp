import { View, Text } from 'react-native'
import React from 'react'
import Tatal from '../PollupAppCom/Tatal'

const TatalEarning = () => {
  return (
    <View style={{flex:1}}>
      <View style={{flexDirection:'row'}}>
      <Tatal imageSource={require("../assets/Groupone.png")}/>
      <Tatal imageSource={require("../assets/Grouptwo.png")}/>
      </View>
      <View style={{flexDirection:'row'}}>
      <Tatal imageSource={require("../assets/Grouptwo.png")}/>
      <Tatal imageSource={require("../assets/Groupthree.png")}/>
      </View>
    </View>
  )
}

export default TatalEarning