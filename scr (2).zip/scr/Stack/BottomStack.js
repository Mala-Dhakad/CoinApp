
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Wallte from './Wallte';
import SurveyOffers from './SurveyOffers';
import Luckydraw from './Luckydraw';
import LuckyDrawWinner from './LuckyDrawWinner';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';



const Tab = createBottomTabNavigator();
const BottomStack = () => {
    return (
        <Tab.Navigator screenOptions={{ headerShown: false }}>
            <Tab.Screen name='Wallet' component={Wallte} options={{
                // tabBarLabel:"Wallet",
                tabBarIcon: ({

                }) => (
                    <MaterialCommunityIcons name="home" color={"black"} size={40} />
                )
            }} />
            <Tab.Screen name="Lucky" component={Luckydraw} />
            <Tab.Screen name="LuckyDraw" component={LuckyDrawWinner} />
            <Tab.Screen name="Streaks" component={SurveyOffers} />
        </Tab.Navigator>
    )
}

export default BottomStack