// import { View, Text, Image, StyleSheet, ImageBackground } from 'react-native';
// import React from 'react';
// import Convert from '../component/Convert';

// const GetLuckyNumber = () => {
//   return (
//     <View style={{ flex: 1 }}>
//       <ImageBackground source={require("../assets/image.png")} style={styles.image}/>
//       <View>
//         <Image source={require("../assets/back.png")} />
//         <Text>Get Lucky Number</Text>
//       </View>
//       <Image source={require("../assets/background.png")}/>


//       <Image source={require("../assets/board.png")}/>
// <Convert/>
//     </View>
//   );
// };

// export default GetLuckyNumber;
// const styles =StyleSheet.create({
//   image:{
//     // flex:1,
// height:"100%",
// width:'100%',
// position:'absolute',
//   }
// })





import { View, Text, ImageBackground, StyleSheet, Image } from 'react-native'
import React from 'react'
import Convert from '../component/Convert'

const GetLuckyNumber = () => {
  return (
    <View style={{flex:1}}>
      <ImageBackground source={require("../assets/image.png")} style={styles.backimage}>
      <View style={styles.row}>
        <Image source={require("../assets/back.png")} style={styles.back}/>
        <Text style={styles.get}>Get Lucky Number</Text>
      </View>
      <Image source={require("../assets/background.png")} style={styles.second}/>
      <Image source={require("../assets/board.png")} style={styles.board}/>
      <Text style={styles.textBelowBoard}>Ratate a Wheel to Select a{"\n"} number</Text>
      {/* <Convert title={"Done"} style={styles.convertButton}/> */}
      </ImageBackground>

    </View>
  )
}

export default GetLuckyNumber
const styles = StyleSheet.create({
  backimage:{
    flex:1,
    height:'100%',
    width:'100%'
  },
  row:{
    flexDirection:'row',
    margin:10,
  },
  get:{
    color:'white',
    textAlign:'center',
    width:'100%',
    fontSize:18,
    fontWeight:'700',
    marginTop:40,
  },
  back:{
    marginTop:40,
   
  },
  second:{
    height:"100%",
    width:'100%',
    borderTopRightRadius:15,
    borderTopLeftRadius:15,
    marginTop:90,
    position:'absolute',
  },
  board:{
    position: 'absolute',      
    top: '25%',
    justifyContent:'center', 
    alignSelf:'center',                             
  },
  textBelowBoard: {
    position: 'absolute',  
    top: '50%',           
    width: '100%',
    textAlign: 'center',   
    fontSize: 15,   
    color: 'black',      
    fontWeight: '400',     
  },
  convertButton: {
    position: 'absolute',
    top: '65%',  
    width: '100%',
    alignSelf: 'center', 
    marginTop: 20, 
  },


}) 