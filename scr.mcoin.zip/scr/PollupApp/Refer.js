import { View, Text } from 'react-native'
import React from 'react'
import ReferCom from '../PollupAppCom/ReferCom'

const Refer = () => {
  return (
    <View>
      <Text>Refer</Text>
      <ReferCom imageSource={require("../assets/Frame.png")}
      title={"Mala Dhakad"}
      titleone={"Facebook"}
      titletwo={"@haysas"}/>
    </View>
  )
}

export default Refer