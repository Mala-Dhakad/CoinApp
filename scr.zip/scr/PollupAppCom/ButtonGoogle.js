import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native'
import React from 'react'

const ButtonGoogle = ({ title, onPress,imageSource,back}) => {
    return (
        <TouchableOpacity onPress={onPress}
        activeOpacity={0.5}>
            <View style={styles.viewStyle}>
                <Image source={imageSource} style={styles.imagestyle} />
              
                    <Text style={styles.textstyle}>{title}</Text>
                    </View>
      
                </TouchableOpacity>
           
    )
}

export default ButtonGoogle
const styles = StyleSheet.create({
    viewStyle: {
    
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: "red",
        borderRadius: 18,
        height: 65,
        width: "100%",
        gap: 20,
        marginTop:10,
    },
    imagestyle: {
        height: 20,
        width: 20,
    },
    textstyle: {
        color: 'red',
        fontSize: 18,
        fontWeight: '800',
    }
})