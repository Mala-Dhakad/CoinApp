import { View, Text } from 'react-native'
import React from 'react'
import ButtonGoogle from '../PollupAppCom/ButtonGoogle'
import Reward from '../PollupAppCom/Reward'

const SplaceScreen = () => {
  return (
    <View>
{/* <ButtonGoogle 
imageSource={require("../assets/Applogo.png")}
title={"Google"}/> */}



<Reward/>
    </View>
  )
}

export default SplaceScreen