import { View, Text, Image, StyleSheet, ImageBackground } from 'react-native'
import React from 'react'
import Button from '../component/Button'
import ButtonBig from '../component/ButtonBig'
import ButtonOne from '../component/ButtonOne'
import Convert from '../component/Convert'

const GetLuckyNumber = () => {
  return (
    <View style={{flex:1,}}>
     <ImageBackground source={require("../assets/image.png")} style={styles.image}/>
     <View style={styles.mainview}>
      <Image source={require("../assets/back.png")}/>
      <Text style={styles.textone}>Get Lucky Number</Text>
     </View>
     <Image source={require("../assets/background.png")} style={styles.oneimage}/>
     <Image source={require("../assets/board.png")} style={styles.board}/>
    <Convert title={"Done"}/>
    </View>
  )
}

export default GetLuckyNumber
const styles =StyleSheet.create({
  image:{
flex:1,
height:"100%",
width:'100%',
position:'absolute',
  },
  mainview:{
flexDirection:'row',
margin:20,

  },
  textone:{
color:'white',
width:"100%",
textAlign:'center',
fontWeight:'800',
fontSize:18,
  },
oneimage:{
flex:1,
height:"90%",
width:'100%',
marginTop:50,
position:'absolute',
},
board:{
height:200,
width:200,
justifyContent:'center',
alignSelf:'center',
},
})