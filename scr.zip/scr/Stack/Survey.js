import { View, Text } from 'react-native'
import React from 'react'
import Oneimage from '../component/Oneimage'

const Survey = () => {
  return (
    <View style={{flex:1}}>
  <Oneimage/>
    </View>
  )
}

export default Survey