import { View, Text, Image, StyleSheet } from 'react-native'
import React from 'react'
import Button from '../component/Button'
import Linear from '../component/Linear'


const Tickets = () => {
    return (
        <View style={{ flex: 1 }}>
            <Image source={require("../assets/image.png")} style={styles.containar} />
            <View style={styles.direction}>
                <Image source={require("../assets/back.png")}/>
                <Text style={{
                    color: 'white',
                    fontSize: 20,
                    width:'100%',
                    textAlign:'center',
                }}>Coins To Tickets</Text>
            </View>
            <Image source={require("../assets/background.png")} style={styles.backimage} />
            <Image source={require("../assets/coinsse.png")} style={styles.secondimage} />
            <Button title={"please enter number of tickets"}/>
            <Linear title={"Convert"}/>
            <Text style={styles.equal}>1ticket is equal to 10 coins</Text>
        </View>
    )
}
const styles = StyleSheet.create({
    containar: {
        flex: 1,
        position: 'absolute',
    },
    direction: {
        flexDirection: 'row',
        marginTop: 50,

    },
    backimage: {
        height: "100%",
        width: "100%",
        marginTop: 100,
        borderTopRightRadius: 18,
        borderTopLeftRadius: 18,
        position: 'absolute',
    },
    secondimage: {
        justifyContent: 'center',
        alignSelf: 'center',
        marginTop: 30,
    },
    equal: {
        justifyContent: 'center',
        alignSelf: 'center',
        marginTop: 30,
        fontSize: 17,
        fontWeight: "500",
    }
})

export default Tickets