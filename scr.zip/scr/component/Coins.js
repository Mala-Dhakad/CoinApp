import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native'
import React from 'react'

const Coins = ({ imageSource, title, onPress, titileone }) => {
  return (
    <View style={{ flex: 1 }}>
      <View style={styles.contenar}>
        <Image source={imageSource} style={styles.image} />
        <Text style={styles.textstyle}>{title}</Text>
        <TouchableOpacity
          onPress={onPress} style={styles.button}>
          <Text style={styles.buttonstyle}>{titileone}</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  contenar: {
    backgroundColor: 'lightgray',
    height: 152,
    width: 152,
  },
  image: {
    height: 50,
    width: 50,
    justifyContent: 'center',
    alignSelf: 'center',
  },
  textstyle:{
    justifyContent:'center',
    alignSelf:'center',
    color:'black',
  },
  button: {
    marginTop:20,
    height: 40,
    width: 80,
    borderRadius: 18,
    color: 'white',
    backgroundColor: 'red',
    justifyContent:'center',
    alignSelf:'center',

  },
  buttonstyle:{
    color:'white',
    justifyContent:'center',
    alignSelf:'center',
    
  }
})
export default Coins