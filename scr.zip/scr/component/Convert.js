import { View, Text, TouchableOpacity, StyleSheet } from 'react-native'
import React from 'react'

const Convert = ({ title, onPress }) => {
  return (
    <View style={{ paddingHorizontal: 25, marginTop: 20, }}>
      <TouchableOpacity
        onPress={onPress} style={styles.buttonstyle}>
        <Text style={styles.textone}>{title}</Text>
      </TouchableOpacity>
    </View>
  )
}
const styles = StyleSheet.create({
  buttonstyle: {
    height: 40,
    width: "100%",
    color: 'black',
    borderWidth: 0.4,
    borderColor: 'back',
    backgroundColor: 'white',
    borderRadius: 18,
  },
  textone: {
    color: 'black',
    fontSize: 18,
    justifyContent: 'center',
    alignSelf: 'center',
    margin: 5,
  }
});

export default Convert;